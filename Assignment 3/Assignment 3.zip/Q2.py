import numpy as np


## global variables

alpha = 0.5
beta = 0.5
max_iters = 50
epsilon = pow(10,-7)


## This function is used to get DFP update B(k+1) from B(k) ,gamma and delta
def DFP_update(B,gamma,delta):

    B = B + np.dot(delta,delta.T)/np.dot(delta.T,gamma) - np.dot(np.dot(B,gamma),np.dot(gamma.T,B))/np.dot(gamma.T,np.dot(B,gamma))
    return B

## this function implememts backtracking line search to get step size in inexact line search
def backtracking_line_search(A,x0,descent_dir):
    iters = 0
    gradient = np.dot(A,x0)
    gradient = gradient.reshape(-1,1)
    t = 1
    func_val_x0 = 0.5*np.dot(x0.T,np.dot(A,x0))
    while iters < max_iters:
        x = x0 + t*descent_dir
        curr_func_val = 0.5*np.dot(x.T,np.dot(A,x))
        if curr_func_val < func_val_x0 + alpha*t*np.dot(gradient.T,descent_dir) or np.linalg.norm(t*descent_dir) < epsilon:
            break
        else:
            t = beta*t
            iters += 1
    return t

## this function implememts steepest descent
def steepest_descent(A,x0):
    
    x = x0
    gradient = np.dot(A,x)
    gradient = gradient.reshape (-1,1)
    iters = 0
    descent_dir = -gradient
    descent_dir = descent_dir.reshape(-1,1)
    while np.linalg.norm(gradient) > epsilon :
        stepsize = -np.dot(gradient.T, descent_dir)/np.dot( descent_dir.T,np.dot(A, descent_dir))
        x = x + stepsize*descent_dir
        gradient = np.dot(A,x)
        descent_dir = -gradient
        iters += 1
        print('Steepest descent -iteration = %d ,function val = %f'%(iters,0.5*np.dot(x.T,np.dot(A,x))))
    return x

## this function implememts DFP with exact line search
def DFP_exact(A,x0):
    x = x0
    gradient = np.dot(A,x)
    gradient = gradient.reshape (-1,1)
    iters = 0
    B = np.identity(6)
    descent_dir = -np.dot(B,gradient)
    descent_dir = descent_dir.reshape(-1,1)
    while iters <6:
        stepsize = -np.dot(gradient.T, descent_dir)/np.dot( descent_dir.T,np.dot(A, descent_dir))
        x = x + stepsize*descent_dir
        gamma = np.dot(A,x) - gradient  ## g_k+1 - g_k 
        gamma = gamma.reshape(-1,1)
        delta = stepsize*descent_dir  ## x_k+1 - x_k
        delta = delta.reshape(-1,1)
        B = DFP_update(B,gamma,delta)
        gradient = np.dot(A,x) 
        descent_dir =  -np.dot(B,gradient)
        iters += 1
        print('DFP Exact -iteration = %d ,function val = %f '%(iters,0.5*np.dot(x.T,np.dot(A,x))))
    return x

#this function implememts DFP with inexact line search                     
def DFP_inexact(A,x0):
    x = x0
    gradient = np.dot(A,x)
    gradient = gradient.reshape (-1,1)
    iters = 0
    B = np.identity(6)
    descent_dir = -np.dot(B,gradient)
    descent_dir = descent_dir.reshape(-1,1)
    while iters < 6 :
        stepsize = backtracking_line_search(A,x,descent_dir)
        x = x + stepsize*descent_dir
        gamma = np.dot(A,x) - gradient  ## g(k+1) - g(k)
        gamma = gamma.reshape(-1,1)
        delta = stepsize*descent_dir  ## x(k+1) - x(k)
        delta = delta.reshape(-1,1)
        B = DFP_update(B,gamma,delta)
        #print(B)
        gradient = np.dot(A,x)  
        descent_dir =  -np.dot(B,gradient)
        iters += 1
        print('DFP Inexact - iteration = %d ,function val = %f'%(iters,0.5*np.dot(x.T,np.dot(A,x))))
    return x

## main calling procedure
if __name__ == '__main__':
    
    SR_No = 19598
    a = SR_No%100
    A = np.diag(np.arange(a+10,a-2,-2))
    x0 = np.full(6,10)
    x0 = x0.reshape(-1,1)
    x = steepest_descent(A,x0)
    print('Converged x after 6 iterations with Steepest Descent = ',end = ' ')
    print(x)
    x = DFP_exact(A,x0)
    print('Converged x after 6 iterations with DFP with exact line search = ',end = ' ')
    print(x)
    x = DFP_inexact(A,x0)
    print('Converged x after 6 iterations with DFP with inexact line search = ',end = ' ')
    print(x)