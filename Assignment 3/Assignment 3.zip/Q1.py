import numpy as np
import matplotlib.pyplot as plt

## implememtation of conjugate gradient descent algorithm
def conjgrad(A, b, x):
    
    error = b - np.dot(A, x)
    u = error
    gr_old = np.dot(error.T, error)
    iters = 0
    y_val = [np.log(np.linalg.norm(error))]
    while np.linalg.norm(error) >1e-6:
        Au = np.dot(A, u)
        alpha = np.dot(error.T, error) / np.dot(u.T, Au)
        x = x + alpha* u
        error = error - alpha* Au
        gr_new = np.dot(error.T, error)
        u = error + (gr_new/gr_old)*u
        y_val.append(np.log(np.linalg.norm(error)))
        gr_old = gr_new
        iters +=1 
    x_val = np.arange(0,iters+1)
    y_val = np.array(y_val)
    plt.figure(0)
    plt.xlabel("log scale Error")
    plt.ylabel(" iterations")
    plt.plot(x_val,y_val)
    plt.show()
    plt.close()
    
    return x,iters

## Main calling procedure
if __name__=='__main__':
    
    N = [5,8,12,20]
    for n in N:
        A = np.zeros((n,n))
        b = np.ones(n)
        b = b.reshape(-1,1)
        x0 = np.zeros(n)
        x0 = x0.reshape(-1,1)
        for i in range(n):
            for j in range(n):
                   A[i,j] = 1/(i+j+1)
        print('n = %d'%n)
        x,iters = conjgrad(A,b,x0)
        print('No. of iterations to converge = %d'%iters)
        print('converged point x = ',end='')
        print(x)